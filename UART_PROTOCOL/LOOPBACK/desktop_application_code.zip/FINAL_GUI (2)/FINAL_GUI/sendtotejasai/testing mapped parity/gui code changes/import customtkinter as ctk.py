import customtkinter as ctk
import threading
from PIL import Image, ImageTk

class App(ctk.CTk):
    def __init__(self, backend):
        super().__init__()
        self.backend = backend
    
        # Get screen dimensions and set window size
        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()
        self.title("MyTestBox")
    # Use 60% of screen width and height
        self.geometry(f"{int(screen_width * 0.6)}x{int(screen_height * 0.6)}")
        self.bind("<Configure>", self.on_resize)

        # Mode for application
        ctk.set_appearance_mode("system")
        ctk.set_default_color_theme("blue")

        # Background gradient setup
        self.configure(bg="#2f323a")
        self.label = ctk.CTkLabel(self, text="Functionality Testing", font=("Helvetica", 20, "bold"), text_color="#000000")
        self.label.grid(row=0, column=0, padx=20, pady=20, sticky="nsew")

        # Configure grid weights for centering
        self.grid_columnconfigure(0, weight=1)  # Left column (UART Testing)
        self.grid_columnconfigure(1, weight=2)  # Middle column (UART Configuration)
        self.grid_columnconfigure(2, weight=1)  # Right column (Result)
        for i in range(8):
            self.grid_rowconfigure(i, weight=1)

       # Test category buttons
        button_width = 200
        button_height = 50

        self.toggle_button_UART = ctk.CTkButton(
        self,
        text="UART Testing",
        command=self.toggle_checkbox_frame_UART,
        font=("Helvetica", 16,"bold"),  # Match font size
        width=button_width,  # Match width
        height=button_height,  # Match height
        corner_radius=10,
        fg_color="#4C6B8B",
        hover_color="#3a5677"
    )
        self.toggle_button_UART.grid(row=1, column=0, pady=10, padx=20, sticky="ew")

        self.toggle_button_I2C = ctk.CTkButton(self, text="I2C Testing", command=self.toggle_checkbox_frame_I2C, font=("Helvetica", 16,"bold"), width=button_width, height=button_height, corner_radius=10, fg_color="#4C6B8B", hover_color="#3a5677")
        self.toggle_button_I2C.grid(row=3, column=0, pady=10, padx=20,sticky="ew")

        self.toggle_button_SPI = ctk.CTkButton(self, text="SPI Testing", command=self.toggle_checkbox_frame_SPI, font=("Helvetica", 16,"bold"), width=button_width, height=button_height, corner_radius=10, fg_color="#4C6B8B", hover_color="#3a5677")
        self.toggle_button_SPI.grid(row=5, column=0, pady=10, padx=20,sticky="ew")

        # Frames for checkboxes
        self.checkbox_frame_UART = ctk.CTkFrame(self, corner_radius=10) #fg_color="#2e3138"
        self.checkbox_frame_I2C = ctk.CTkFrame(self, corner_radius=10)
        self.checkbox_frame_SPI = ctk.CTkFrame(self, corner_radius=10)

        self.checkbox_frame_UART.grid(row=2, column=0, pady=10, padx=20, sticky="nsew")
        self.checkbox_frame_I2C.grid(row=4, column=0, pady=10, padx=20, sticky="nsew")
        self.checkbox_frame_SPI.grid(row=6, column=0, pady=10, padx=20, sticky="nsew")

        self.checkbox_frame_UART.grid_forget()
        self.checkbox_frame_I2C.grid_forget()
        self.checkbox_frame_SPI.grid_forget()

        # Test selection checkboxes
        self.checkbox_vars_UART = {
            "UART Read Testing": ctk.BooleanVar(value=False),
            "UART Write Testing": ctk.BooleanVar(value=False),
            "UART Loopback Testing": ctk.BooleanVar(value=False),
            "UART Parity Testing": ctk.BooleanVar(value=False),
            "UART BaudRate Testing": ctk.BooleanVar(value=False),
            #"UART Stress Testing": ctk.BooleanVar(value=False),
            #"UART Endurance Testing": ctk.BooleanVar(value=False),
            #"UART Interoperability Testing": ctk.BooleanVar(value=False)
        }

        self.checkbox_vars_I2C = {
            "I2C_Load Testing": ctk.BooleanVar(value=False),
            "I2C_Stress Testing": ctk.BooleanVar(value=False),
            "I2C_Endurance Testing": ctk.BooleanVar(value=False),
            "I2C_Interoperability Testing": ctk.BooleanVar(value=False)
        }

        self.checkbox_vars_SPI = {
            "SPI_Load Testing": ctk.BooleanVar(value=False),
            "SPI_Stress Testing": ctk.BooleanVar(value=False),
            "SPI_Endurance Testing": ctk.BooleanVar(value=False),
            "SPI_Interoperability Testing": ctk.BooleanVar(value=False)
        }

        self.populate_checkboxes(self.checkbox_frame_UART, self.checkbox_vars_UART, self.show_selection)
        self.populate_checkboxes(self.checkbox_frame_I2C, self.checkbox_vars_I2C, self.show_selection)
        self.populate_checkboxes(self.checkbox_frame_SPI, self.checkbox_vars_SPI, self.show_selection)

        # Test button
        image_path = "static/images/starttest1.png"
        image = Image.open(image_path)
        ctk_image = ctk.CTkImage(light_image=image, dark_image=image)

        self.test_button = ctk.CTkButton(
        self, 
        text="Run Test", 
        image=ctk_image,
        command=self.test_backend, 
        font=("Helvetica", 16, "bold"),
        width=140, 
        height=35, 
        corner_radius=10,
        fg_color="#1f968e", 
        hover_color="#75ADB9"
    )
        self.test_button.grid_forget()


        # Result label
        # self.result_label = ctk.CTkLabel(self, text="Result: ", font=("Helvetica", 14), text_color="lightgray")
        # self.result_label.grid(row=8, column=2, columnspan=2, pady=20)
        # self.result_label.configure(text="Result: []")
    def test_setup_check(self):
        # Create a "Result" label (Title) at the top 
        self.result_label_title = ctk.CTkLabel(  
        self,  
        text="Result",  
        font=("Helvetica", 16, "bold"),  
        text_color="#FFFFFF",  
        fg_color="#4C6B8B",  
        height=40,  # Fixed height  
        corner_radius=10,  
)  

        self.result_label_title.grid(row=1, column=2, sticky="nsew", padx=20, pady=10)

        # Create a frame for the result area in column 2 with fixed width and height
        self.result_frame = ctk.CTkFrame(self, width=250, height=80, corner_radius=10)
        self.result_frame.grid(row=2, column=2, sticky="nsew", padx=50, pady=20, columnspan = 2)

        # Placeholder label inside the frame (will show the result text)
        self.result_label = ctk.CTkLabel(self.result_frame, text="", font=("Helvetica", 14), text_color="white", wraplength=240)
        self.result_label.place(relx=0.5, rely=0.3, anchor="n")  # Center the label inside the frame

        # Dynamically updating the result label
        self.result_label.configure(text="")  # Initially empty, can be updated later with actual result text

        

    def input_output_frame_UART(self):
        #Input frame feild from GUI
        self.input_frame = ctk.CTkFrame(self)
        self.input_frame.grid(row=4, column=1, pady=10, padx=20, sticky="nsew")
        
        # Title label for input section
        guitext_Input = ctk.CTkLabel(self.input_frame, text="Input", font=("Helvetica", 20, "bold"), text_color="#000000")
        guitext_Input.grid(row=0, column=0, pady=20, padx=50, sticky="nsew", columnspan=2)  # Columnspan to center the title
        # Label for the input field
        self.input_frame_label = ctk.CTkLabel(self.input_frame, text="Enter Input:")
        self.input_frame_label.grid(row=1, column=0, padx=10, pady=10, sticky="e")  # Align label to the right (east)
        # Input field with placeholder text
        self.input_frame_entry = ctk.CTkEntry(self.input_frame, placeholder_text="Enter something", width=int(self.winfo_screenwidth() * 0.2), height=40)
        self.input_frame_entry.grid(row=1, column=1, padx=10, pady=10, sticky="w")  # Align entry to the left (west)
        # Submit button
        input_button = ctk.CTkButton(self.input_frame, text="Send", command=self.submit_input)
        input_button.grid(row=2, column=1, pady=10, padx=10, sticky="w")  # Align button to the left of its cell
        
        # Create the output frame
        self.output_frame = ctk.CTkFrame(self)
        self.output_frame.grid(row=4, column=2, pady=10, padx=20, sticky="nsew")
        # Title label for output section
        output_label = ctk.CTkLabel(self.output_frame, text="Output", font=("Helvetica", 20, "bold"), text_color="#000000")
        output_label.grid(row=0, column=0, pady=10, padx=50, sticky="nsew",columnspan=2)
        # Output text label
        self.output_label = ctk.CTkLabel(self.output_frame, text="", font=("Helvetica", 14), text_color="#000000")
        self.output_label.place(relx=0.5, rely=0.3, anchor="n")
        self.output_frame.grid_rowconfigure(1, weight=1)  # Allow row 1 to grow
        self.output_frame.grid_columnconfigure(0, weight=1)  # Allow column 0 to grow
        self.output_frame.grid_columnconfigure(1, weight=1)  # Allow column 1 to grow

        self.send_button = ctk.CTkButton(self.input_frame, text="Send", command=self.submit_input)
        self.send_button.grid(row=2, column=1, pady=10, padx=10, sticky="w")

        self.rdbnn_frame = ctk.CTkFrame(self)
        self.rdbnn_frame.grid(row=3, column=1,padx=50, pady=10, sticky="nsew")

        self.parity_label = ctk.CTkLabel(self.rdbnn_frame, text="DUT Parity Set")
        self.parity_label.grid(row=0, column=0, columnspan=3, padx=10, pady=5, sticky="w")

        self.parity_var = ctk.StringVar(value="None")  # Default value set to "None"

        self.radio_none = ctk.CTkRadioButton(self.rdbnn_frame, text="None", variable=self.parity_var, value="None", command=lambda: self.on_parity_change())
        self.radio_even = ctk.CTkRadioButton(self.rdbnn_frame, text="Even", variable=self.parity_var, value="Even", command=lambda: self.on_parity_change())
        self.radio_odd = ctk.CTkRadioButton(self.rdbnn_frame, text="Odd", variable=self.parity_var, value="Odd", command=lambda: self.on_parity_change())

        # Place the radio buttons in one row
        self.radio_none.grid(row=1, column=0, padx=10, pady=5, sticky="w")
        self.radio_even.grid(row=1, column=1, padx=10, pady=5, sticky="w")
        self.radio_odd.grid(row=1, column=2, padx=10, pady=5, sticky="w")


    def on_parity_change(self):
        dut_set_parity = self.parity_var.get()
        self.backend.set_parity(dut_set_parity)
        print(f"Selected Parity: {dut_set_parity}")

    
    def submit_input(self):
        # Get the user input from the input field
        user_input = self.input_frame_entry.get()
        result = self.backend.process_input_data(user_input)
        processed_result = user_input
        # Display the result in the output label
        self.output_label.configure(text=f"Input Data Result: {result}")
        self.output_label.update_idletasks()
    
    
    def populate_checkboxes(self, frame, checkbox_vars, command):
        for idx, (text, var) in enumerate(checkbox_vars.items()):
            checkbox = ctk.CTkCheckBox(frame, text=text, variable=var, onvalue=True, offvalue=False, font=("Helvetica", 14), command=command)
            checkbox.grid(row=idx, column=0, padx=20, pady=10, sticky="w")

    def toggle_checkbox_frame_UART(self):
        self.hide_all_checkbox_frames()
        self.show_uart_configuration_form()# Show UART configuration form when clicked
        self.test_setup_check() # Show result selection after clicking UART Testing button
        self.input_output_frame_UART()
        
        if not self.checkbox_frame_UART.winfo_ismapped():
            self.checkbox_frame_UART.grid(row=2, column=0, pady=20, padx=50, sticky="nsew")


    def toggle_checkbox_frame_I2C(self):
        self.hide_all_checkbox_frames()
        if not self.checkbox_frame_I2C.winfo_ismapped():
            self.checkbox_frame_I2C.grid(row=4, column=0, pady=20, padx=50, sticky="nsew")

    def toggle_checkbox_frame_SPI(self):
        self.hide_all_checkbox_frames()
        if not self.checkbox_frame_SPI.winfo_ismapped():
            self.checkbox_frame_SPI.grid(row=6, column=0, pady=20, padx=50, sticky="nsew")

    def hide_all_checkbox_frames(self):
        self.checkbox_frame_UART.grid_forget()
        self.checkbox_frame_I2C.grid_forget()
        self.checkbox_frame_SPI.grid_forget()

    def show_selection(self):
        if any(var.get() for var in self.checkbox_vars_UART.values()) or \
            any(var.get() for var in self.checkbox_vars_I2C.values()) or \
            any(var.get() for var in self.checkbox_vars_SPI.values()):
            self.test_button.grid(row=8, column=0, pady=20, padx=50)  
        else:
            self.test_button.grid_forget()

    def show_uart_configuration_form(self):
        # UART configuration form when UART Testing is selected
        # In the show_uart_configuration_form method, add these lines at the start:
    
        self.uart_frame = ctk.CTkFrame(self)
        self.uart_frame.grid(row=2, column=1, pady=20, padx=50, sticky="nsew")
        self.uart_frame.grid_columnconfigure(0, weight=1)
        self.uart_frame.grid_columnconfigure(1, weight=2)

        self.result_label_title = ctk.CTkLabel( self,  
        text="UART Configuration",  
        font=("Helvetica", 16, "bold"),  
        text_color="#FFFFFF",  
        fg_color="#4C6B8B",  
        height=40,  # Fixed height  
        corner_radius=10,  
    )  

        self.result_label_title.grid(row=1, column=1, sticky="nsew", padx=20, pady=10)

        #title_label = ctk.CTkLabel(self.uart_frame,text="UART Configuration",font=("Helvetica", 18, "bold"),text_color="#000000")
        #title_label.grid(row=1, column=1, columnspan=2, pady=10)

        # for Baud Rate
        self.baud_rate_label = ctk.CTkLabel(self.uart_frame, text="Baud Rate:")
        self.baud_rate_label.grid(row=2, column=0, padx=10, pady=10, sticky="e")
        self.baud_rate_entry = ctk.CTkOptionMenu(self.uart_frame, values=["600","1200","2400", "4800", "9600","14400","19200","38400","56000","57600", "115200"], state="normal")
        self.baud_rate_entry.grid(row=2, column=1, padx=10, pady=10)
        self.baud_rate_entry.set(9600)

        # for Stop Bit
        self.stop_bit_label = ctk.CTkLabel(self.uart_frame, text="Stop Bit:")
        self.stop_bit_label.grid(row=3, column=0, padx=10, pady=10, sticky="e")
        self.stop_bit_entry = ctk.CTkEntry(self.uart_frame)
        self.stop_bit_entry.grid(row=3, column=1, padx=10, pady=10)

        # for Parity
        self.parity_label = ctk.CTkLabel(self.uart_frame, text="Parity:")
        self.parity_label.grid(row=4, column=0, padx=10, pady=10, sticky="e")
        self.parity_var = ctk.StringVar(value="None")
        self.parity_odd = ctk.CTkRadioButton(self.uart_frame, text="Odd", variable=self.parity_var, value="Odd")
        self.parity_odd.grid(row=4, column=1, padx=10, pady=10, sticky="w")
        self.parity_even = ctk.CTkRadioButton(self.uart_frame, text="Even", variable=self.parity_var, value="Even")
        self.parity_even.grid(row=4, column=2, padx=10, pady=10, sticky="w")
        self.parity_none = ctk.CTkRadioButton(self.uart_frame, text="None", variable=self.parity_var, value="None")
        self.parity_none.grid(row=4, column=3, padx=10, pady=10, sticky="w")

        # for Data Shift
        self.data_shift_label = ctk.CTkLabel(self.uart_frame, text="Data Shift:")
        self.data_shift_label.grid(row=5, column=0, padx=10, pady=10, sticky="e")
        self.data_shift_var = ctk.StringVar(value="MSB First")
        self.data_shift_msb = ctk.CTkRadioButton(self.uart_frame, text="MSB First", variable=self.data_shift_var, value="MSB First")
        self.data_shift_msb.grid(row=5, column=1, padx=10, pady=10, sticky="w")
        self.data_shift_lsb = ctk.CTkRadioButton(self.uart_frame, text="LSB First", variable=self.data_shift_var, value="LSB First")
        self.data_shift_lsb.grid(row=5, column=2, padx=10, pady=10, sticky="w")

        # for Handshake
        self.handshake_label = ctk.CTkLabel(self.uart_frame, text="Handshake:")
        self.handshake_label.grid(row=6, column=0, padx=10, pady=10, sticky="e")
        self.handshake_var = ctk.StringVar(value="OFF")
        self.handshake_off = ctk.CTkRadioButton(self.uart_frame, text="OFF", variable=self.handshake_var, value="OFF")
        self.handshake_off.grid(row=6, column=1, padx=10, pady=10, sticky="w")
        self.handshake_rts_cts = ctk.CTkRadioButton(self.uart_frame, text="RTS/CTS", variable=self.handshake_var, value="RTS/CTS")
        self.handshake_rts_cts.grid(row=6, column=2, padx=10, pady=10, sticky="w")
        self.handshake_xon_xoff = ctk.CTkRadioButton(self.uart_frame, text="Xon/Xoff", variable=self.handshake_var, value="Xon/Xoff")
        self.handshake_xon_xoff.grid(row=6, column=3, padx=10, pady=10, sticky="w")

        # Submit Button to process UART config
        image_submitconfig_path = "static/images/submitconfig.png"
        image_submitconfig = Image.open(image_submitconfig_path)
        ctk_image_submitconfig = ctk.CTkImage(light_image=image_submitconfig, dark_image=image_submitconfig)

        self.submit_button = ctk.CTkButton(self.uart_frame, text="Submit Configuration", image = ctk_image_submitconfig, command=self.submit_uart_configuration)
        self.submit_button.grid(row=7, column=0, columnspan=4, pady=20)

        

    def submit_uart_configuration(self):
        # Get values from the input fields
        baud_rate = self.baud_rate_entry.get()
        stop_bit = self.stop_bit_entry.get()
        parity = self.parity_var.get()
        data_shift = self.data_shift_var.get()
        handshake = self.handshake_var.get()
        input_data = self.input_frame_entry.get()

        # Perform validation
        try:
            stop_bit = float(stop_bit)
            if stop_bit not in [1,1.5,2]:
                raise ValueError("Stop bit must be either 1, 1.5, or 2")
            baud_rate = int(baud_rate)
        except ValueError as e:
            self.result_label.configure(text=str(e), text_color="red")
            return
        result = self.backend.process_uart_configuration(baud_rate, stop_bit, parity, data_shift, handshake)
        if "Error" in result:
            self.result_label.configure(text=result, text_color="red")
        else:
            self.result_label.configure(text=result, text_color="green") 
        

    def test_backend(self):
        selected_tests = []
        selected_tests += [test for test, var in self.checkbox_vars_UART.items() if var.get()]
        selected_tests += [test for test, var in self.checkbox_vars_I2C.items() if var.get()]
        selected_tests += [test for test, var in self.checkbox_vars_SPI.items() if var.get()]

        if selected_tests:
            threading.Thread(target=self.run_test, daemon=True).start()
        else:
            self.result_label.configure(text="No tests selected", text_color="red")

    def run_test(self):
        selected_tests = [test for test, var in self.checkbox_vars_UART.items() if var.get()]
        if not selected_tests:
            self.result_label.configure(text="No tests selected", text_color="red")
            return

    # Disable the Run Test button to prevent multiple clicks
        self.test_button.configure(state="disabled")
    
    # Start a new thread for the test execution
        threading.Thread(target=self._run_test_thread, args=(selected_tests,), daemon=True).start()

    def _run_test_thread(self, selected_tests):
        try:
            result = self.backend.run_test(selected_tests)
            # Update the output label instead of result label
            self.after(0, lambda: self.output_label.configure(
            text=result, text_color="green"))
        except Exception as e:
            self.after(0, lambda: self.output_label.configure(
                text=f"Error: {str(e)}", text_color="red"))
        finally:
            self.after(0, lambda: self.test_button.configure(state="normal"))

    def on_resize(self, event):
        """Adjust UI elements on window resize"""
        width = self.winfo_width()
        if hasattr(self, 'input_frame_entry'):
            self.input_frame_entry.configure(width=int(width * 0.2))
        if hasattr(self, 'toggle_button_UART'):
            self.toggle_button_UART.configure(width=int(width * 0.1))