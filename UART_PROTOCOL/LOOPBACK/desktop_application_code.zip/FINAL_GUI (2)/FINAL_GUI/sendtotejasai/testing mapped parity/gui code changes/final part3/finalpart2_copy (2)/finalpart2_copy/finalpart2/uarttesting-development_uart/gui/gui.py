import customtkinter as ctk
import threading
from PIL import Image, ImageTk

class App(ctk.CTk):
    def __init__(self, backend):
        super().__init__()
        self.backend = backend
    
        # Get screen dimensions and set window size
        screen_width = self.winfo_screenwidth()
        screen_height = self.winfo_screenheight()
          # Set a larger window size by default (85% of screen)
        window_width = int(screen_width * 0.85)
        window_height = int(screen_height * 0.9)
        
        # Set minimum window size to ensure adequate space
        self.minsize(1000, 800)  # Increased minimum height to 800
        
        # Set the window size
        self.geometry(f"{window_width}x{window_height}")
        self.title("MyTestBox")
    # Use 60% of screen width and height
       # self.geometry(f"{int(screen_width * 0.6)}x{int(screen_height * 0.6)}")
        self.bind("<Configure>", self.on_resize)

        # Mode for application
        ctk.set_appearance_mode("system")
        ctk.set_default_color_theme("blue")

        # Background gradient setup
        self.configure(bg="#2f323a")
        #self.label = ctk.CTkLabel(self, text="Functionality Testing", font=("Helvetica", 20, "bold"), text_color="#000000")
       # self.label.grid(row=0, column=0, padx=20, pady=20, sticky="nsew")

        # Configure grid weights for centering
        self.grid_columnconfigure(0, weight=1)  # Left column (UART Testing)
        self.grid_columnconfigure(1, weight=2)  # Middle column (UART Configuration)
        self.grid_columnconfigure(2, weight=1)  # Right column (Result)
        # Configure row weights
        self.grid_rowconfigure(0, weight=0)  # Header row (fixed)
        for i in range(8):
            self.grid_rowconfigure(i, weight=1)

       # Test category buttons
        button_width = 200
        button_height = 50

        self.toggle_button_UART = ctk.CTkButton(
        self,
        text="UART Testing",
        command=self.toggle_checkbox_frame_UART,
        font=("Helvetica", 16,"bold"),  # Match font size
        width=button_width,  # Match width
        height=button_height,  # Match height
        corner_radius=10,
        fg_color="#4C6B8B",
        hover_color="#3a5677"
    )
        self.toggle_button_UART.grid(row=1, column=0, pady=10, padx=20, sticky="ew")

        self.toggle_button_I2C = ctk.CTkButton(self, text="I2C Testing", command=self.toggle_checkbox_frame_I2C, font=("Helvetica", 16,"bold"), width=button_width, height=button_height, corner_radius=10, fg_color="#4C6B8B", hover_color="#3a5677")
        self.toggle_button_I2C.grid(row=3, column=0, pady=10, padx=20,sticky="ew")

        self.toggle_button_SPI = ctk.CTkButton(self, text="SPI Testing", command=self.toggle_checkbox_frame_SPI, font=("Helvetica", 16,"bold"), width=button_width, height=button_height, corner_radius=10, fg_color="#4C6B8B", hover_color="#3a5677")
        self.toggle_button_SPI.grid(row=5, column=0, pady=10, padx=20,sticky="ew")

        # Frames for checkboxes
        self.checkbox_frame_UART = ctk.CTkFrame(self, corner_radius=10) #fg_color="#2e3138"
        self.checkbox_frame_I2C = ctk.CTkFrame(self, corner_radius=10)
        self.checkbox_frame_SPI = ctk.CTkFrame(self, corner_radius=10)

        self.checkbox_frame_UART.grid(row=2, column=0, pady=10, padx=20, sticky="nsew")
        self.checkbox_frame_I2C.grid(row=4, column=0, pady=10, padx=20, sticky="nsew")
        self.checkbox_frame_SPI.grid(row=6, column=0, pady=10, padx=20, sticky="nsew")

        self.checkbox_frame_UART.grid_forget()
        self.checkbox_frame_I2C.grid_forget()
        self.checkbox_frame_SPI.grid_forget()

        # Test selection checkboxes
        self.checkbox_vars_UART = {
            "Basic UART Communication Test": {
                "expanded": ctk.BooleanVar(value=False),  # Controls if section is expanded
                "subtests": {
                    "Reception Test": ctk.BooleanVar(value=False),
                    "Transmission Test": ctk.BooleanVar(value=False),
                    "Loopback Test": ctk.BooleanVar(value=False),
        
                }
            },
              "Configuration Testing": {
                "expanded": ctk.BooleanVar(value=False),
                "subtests": {
                    "Baud Rate Accuracy Testing": ctk.BooleanVar(value=False),
                    "Data Bits": ctk.BooleanVar(value=False),
                    "Stop Bits Configuration": ctk.BooleanVar(value=False)
                }
            },
             "Flow Control Testing": {
                "expanded": ctk.BooleanVar(value=False),
                "subtests": {
                    "RTS/CTS Hardware Flow Control Test": ctk.BooleanVar(value=False),
                    "XON/XOFF Software Flow Test": ctk.BooleanVar(value=False)
                }
            },
            "Error Detection": {
                "expanded": ctk.BooleanVar(value=False),
                "subtests": {
                    "Parity Detection": ctk.BooleanVar(value=False),
                    "Overrun Detection": ctk.BooleanVar(value=False),
                    "Framing Detection": {
                        "expanded": ctk.BooleanVar(value=False),
                        "subtests": {
                            "BaudRate Mismatch": ctk.BooleanVar(value=False),
                            "StopBit Mismatch": ctk.BooleanVar(value=False),
                            "Break Character Detection": ctk.BooleanVar(value=False),
                             "Noise Detection": ctk.BooleanVar(value=False)
                        }
                    }
                }
            }
        }
           
        self.subtest_frames = {}
        self.nested_subtest_frames = {}

        self.checkbox_vars_I2C = {
            "I2C_Load Testing": ctk.BooleanVar(value=False),
            "I2C_Stress Testing": ctk.BooleanVar(value=False),
            "I2C_Endurance Testing": ctk.BooleanVar(value=False),
            "I2C_Interoperability Testing": ctk.BooleanVar(value=False)
        }

        self.checkbox_vars_SPI = {
            "SPI_Load Testing": ctk.BooleanVar(value=False),
            "SPI_Stress Testing": ctk.BooleanVar(value=False),
            "SPI_Endurance Testing": ctk.BooleanVar(value=False),
            "SPI_Interoperability Testing": ctk.BooleanVar(value=False)
        }

        self.populate_checkboxes(self.checkbox_frame_UART, self.checkbox_vars_UART, self.show_selection)
        self.populate_checkboxes(self.checkbox_frame_I2C, self.checkbox_vars_I2C, self.show_selection)
        self.populate_checkboxes(self.checkbox_frame_SPI, self.checkbox_vars_SPI, self.show_selection)

        # Test button
        image_path = "static/images/starttest1.png"
        image = Image.open(image_path)
        ctk_image = ctk.CTkImage(light_image=image, dark_image=image)
        #self.create_main_layout()
        #self.update_idletasks()

        self.test_button = ctk.CTkButton(
        self, 
        text="Run Test", 
        image=ctk_image,
        command=self.test_backend, 
        font=("Helvetica", 16, "bold"),
        width=120, 
        height=35, 
        corner_radius=10,
        fg_color="#1f968e", 
        hover_color="#75ADB9"
    )
        self.test_button.grid_forget()


        # Result label
        # self.result_label = ctk.CTkLabel(self, text="Result: ", font=("Helvetica", 14), text_color="lightgray")
        # self.result_label.grid(row=8, column=2, columnspan=2, pady=20)
        # self.result_label.configure(text="Result: []")
    def test_setup_check(self):
        # Create a "Result" label (Title) at the top 
        #self.result_label_title = ctk.CTkLabel(  
        #self,  
        #text="Testing Status",  
        #font=("Helvetica", 16, "bold"),  
        #text_color="#FFFFFF",  
        #fg_color="#4C6B8B",  
        #height=40,  # Fixed height  
        #corner_radius=10,  
#)  

        #self.result_label_title.grid(row=1, column=2, sticky="nsew", padx=20, pady=10)

        # Create a frame for the result area in column 2 with fixed width and height
        self.result_frame = ctk.CTkFrame(self, width=250, height=80, corner_radius=10)
        self.result_frame.grid(row=2, column=2, sticky="nsew", padx=50, pady=20, columnspan = 2)

        # Placeholder label inside the frame (will show the result text)
        self.result_label = ctk.CTkLabel(self.result_frame, text="", font=("Helvetica", 14), text_color="white", wraplength=240)
        self.result_label.place(relx=0.5, rely=0.3, anchor="n")  # Center the label inside the frame

        # Dynamically updating the result label
        self.result_label.configure(text="")  # Initially empty, can be updated later with actual result text

        

    def input_output_frame_UART(self):
        # Use consistent row numbers to reduce gaps
        frame_width = int(self.winfo_width() * 0.35)
        
        # Create DUT Parity Set frame directly below UART config (row 2 + 1 = row 3)
        self.rdbnn_frame = ctk.CTkFrame(self)
        self.rdbnn_frame.grid(row=3, column=1, padx=50, pady=(0, 5), sticky="nsew")  # Reduced top padding
        self.rdbnn_frame.configure(width=frame_width)
        
        # Add DUT Parity Set controls
        self.parity_label = ctk.CTkLabel(self.rdbnn_frame, text="DUT Parity Set", font=("Helvetica", 14, "bold"))
        self.parity_label.grid(row=0, column=0, columnspan=3, padx=10, pady=5, sticky="w")
        
        self.parity_var = ctk.StringVar(value="None")
        
        self.radio_none = ctk.CTkRadioButton(self.rdbnn_frame, text="None", variable=self.parity_var, value="None", command=lambda: self.on_parity_change())
        self.radio_even = ctk.CTkRadioButton(self.rdbnn_frame, text="Even", variable=self.parity_var, value="Even", command=lambda: self.on_parity_change())
        self.radio_odd = ctk.CTkRadioButton(self.rdbnn_frame, text="Odd", variable=self.parity_var, value="Odd", command=lambda: self.on_parity_change())
        
        # Place the radio buttons in one row
        self.radio_none.grid(row=1, column=0, padx=10, pady=5, sticky="w")
        self.radio_even.grid(row=1, column=1, padx=10, pady=5, sticky="w")
        self.radio_odd.grid(row=1, column=2, padx=10, pady=5, sticky="w")
        
        # Create the input frame immediately after the DUT Parity set (row 3 + 1 = row 4)
        self.input_frame = ctk.CTkFrame(self)
        self.input_frame.grid(row=4, column=1, pady=(0, 5), padx=50, sticky="nsew")  # Reduced top padding
        self.input_frame.configure(width=frame_width)
        
        # Compact the input UI elements
        guitext_Input = ctk.CTkLabel(self.input_frame, text="Input", font=("Helvetica", 16, "bold"), text_color="#000000")
        guitext_Input.grid(row=0, column=0, pady=(5, 5), padx=20, sticky="w", columnspan=2)  # Reduced padding
        
        # Make the layout more compact
        self.input_frame_label = ctk.CTkLabel(self.input_frame, text="Enter Input:")
        self.input_frame_label.grid(row=1, column=0, padx=10, pady=5, sticky="e")  # Reduced padding
        
        self.input_frame_entry = ctk.CTkEntry(self.input_frame, placeholder_text="Enter something", width=int(self.winfo_screenwidth() * 0.2), height=35)
        self.input_frame_entry.grid(row=1, column=1, padx=10, pady=5, sticky="w")  # Reduced padding
        
        input_button = ctk.CTkButton(self.input_frame, text="Send", command=self.submit_input)
        input_button.grid(row=2, column=1, pady=5, padx=10, sticky="w")  # Reduced padding
        
        # Create the output frame
        self.output_frame = ctk.CTkFrame(self)
        self.output_frame.grid(row=4, column=2, pady=(0, 5), padx=20, sticky="nsew")  # Match the input frame row
        
        # More compact output layout
        output_label = ctk.CTkLabel(self.output_frame, text="Output Result", font=("Helvetica", 16, "bold"), text_color="#000000")
        output_label.grid(row=0, column=0, pady=(5, 5), padx=20, sticky="w", columnspan=2)  # Reduced padding
        
        self.output_label = ctk.CTkLabel(self.output_frame, text="", font=("Helvetica", 14), text_color="#000000")
        self.output_label.place(relx=0.5, rely=0.3, anchor="n")
        
        self.output_frame.grid_rowconfigure(1, weight=1)
        self.output_frame.grid_columnconfigure(0, weight=1)
        self.output_frame.grid_columnconfigure(1, weight=1)
        
        # Prevent frames from resizing themselves
        self.rdbnn_frame.grid_propagate(False)
        self.input_frame.grid_propagate(False)


    def on_parity_change(self):
        dut_set_parity = self.parity_var.get()
        self.backend.set_parity(dut_set_parity)
        print(f"Selected Parity: {dut_set_parity}")

    
    def submit_input(self):
        """Handle input submission with better UI feedback"""
        # Get the user input from the input field
        user_input = self.input_entry.get()
        
        if not user_input:
            # Show a warning if input is empty
            self.status_label.configure(text="Input Error", text_color="orange")
            self.output_label.configure(text="Please enter input data", text_color="orange")
            return
        
        # Show processing indicator
        self.status_label.configure(text="Processing Input", text_color="blue")
        self.output_label.configure(text="Processing input...", text_color="blue")
        self.update_idletasks()
        
        # Process the input
        try:
            result = self.backend.process_input_data(user_input)
            # Display the result with success styling
            self.status_label.configure(text="Input Processed Successfully", text_color="green")
            self.output_label.configure(text=f"Input Data Result: {result}", text_color="green")
        except Exception as e:
            # Handle errors gracefully
            self.status_label.configure(text="Input Processing Failed", text_color="red")
            self.output_label.configure(text=f"Error processing input: {str(e)}", text_color="red")
        
        self.update_idletasks()
    def populate_checkboxes(self, frame, checkbox_vars, command):
        """Create collapsible sections with dropdown buttons for UART tests"""
        row = 0
        
        # Check if it's UART checkboxes (which have the nested structure)
        if any(isinstance(data, dict) and "subtests" in data for data in checkbox_vars.values()):
            # Handle the nested structure for UART
            for category, data in checkbox_vars.items():
                # Create a frame for the dropdown button
                dropdown_frame = ctk.CTkFrame(frame, corner_radius=5)
                dropdown_frame.grid(row=row, column=0, padx=5, pady=(5, 0), sticky="ew")
                dropdown_frame.grid_columnconfigure(0, weight=1)
                
                # Use a custom button for the dropdown header
                icon_text = "▼" if data["expanded"].get() else "▶"
                
                # We need to use a lambda that captures the current value of 'category'
                toggle_cmd = lambda c=category: self.toggle_category_expansion(c)
                
                dropdown_button = ctk.CTkButton(
                    dropdown_frame,
                    text=f"{icon_text} {category}",
                    anchor="w",
                    fg_color="#4C6B8B",
                    hover_color="#3a5677",
                    corner_radius=5,
                    height=30,  # Smaller height
                    font=("Helvetica", 12, "bold"),
                    command=toggle_cmd
                )
                dropdown_button.grid(row=0, column=0, sticky="ew", padx=2, pady=2)
                
                # Create a frame for subtests (will be shown/hidden)
                subtest_frame = ctk.CTkFrame(frame, corner_radius=5)
                self.subtest_frames[category] = subtest_frame
                subtest_frame.grid(row=row+1, column=0, padx=10, pady=(0, 5), sticky="ew")
                
                # Add checkboxes to the subtest frame - make them more compact
                subtest_row = 0
                if "subtests" in data:
                    for subtest_text, subtest_data in data["subtests"].items():
                        if isinstance(subtest_data, dict) and "subtests" in subtest_data:
                            # This is a nested subtest with its own children
                            nested_frame = ctk.CTkFrame(subtest_frame, corner_radius=5)
                            nested_frame.grid(row=subtest_row, column=0, padx=5, pady=1, sticky="ew")
                            nested_frame.grid_columnconfigure(0, weight=1)
                            
                            # Create dropdown for the nested subtest
                            nested_icon = "▼" if subtest_data["expanded"].get() else "▶"
                            
                            # We need to use a lambda that captures both category and subtest_text
                            nested_toggle_cmd = lambda c=category, s=subtest_text: self.toggle_subtest_expansion(c, s)
                            
                            nested_button = ctk.CTkButton(
                                nested_frame,
                                text=f"{nested_icon} {subtest_text}",
                                anchor="w",
                                fg_color="#5B7D9E",  # Slightly different color
                                hover_color="#4A6A8A",
                                corner_radius=5,
                                height=25,  # Even smaller height
                                font=("Helvetica", 11),
                                command=nested_toggle_cmd
                            )
                            nested_button.grid(row=0, column=0, sticky="ew", padx=2, pady=2)
                            
                            # Create a frame for the nested subtests
                            nested_subtest_frame = ctk.CTkFrame(subtest_frame, corner_radius=5)
                            
                            # Store the reference to this nested frame
                            if category not in self.nested_subtest_frames:
                                self.nested_subtest_frames[category] = {}
                            self.nested_subtest_frames[category][subtest_text] = nested_subtest_frame
                            
                            nested_subtest_frame.grid(row=subtest_row+1, column=0, padx=15, pady=(0, 1), sticky="ew")
                            
                            # Add checkboxes for the nested subtests
                            nested_row = 0
                            for nested_text, nested_var in subtest_data["subtests"].items():
                                nested_checkbox = ctk.CTkCheckBox(
                                    nested_subtest_frame,
                                    text=nested_text,
                                    variable=nested_var,
                                    onvalue=True,
                                    offvalue=False,
                                    font=("Helvetica", 10),  # Smaller font
                                    command=command
                                )
                                nested_checkbox.grid(row=nested_row, column=0, padx=5, pady=1, sticky="w")
                                nested_row += 1
                            
                            # Hide nested subtest frame if not expanded
                            if not subtest_data["expanded"].get():
                                nested_subtest_frame.grid_remove()
                            
                            # Increment row by 2 for the nested dropdown and its content
                            subtest_row += 2
                        else:
                            # Regular checkbox for normal subtests
                            subtest_checkbox = ctk.CTkCheckBox(
                                subtest_frame, 
                                text=subtest_text, 
                                variable=subtest_data, 
                                onvalue=True, 
                                offvalue=False, 
                                font=("Helvetica", 11),  # Smaller font
                                command=command
                            )
                            subtest_checkbox.grid(row=subtest_row, column=0, padx=5, pady=1, sticky="w")
                            subtest_row += 1
                
                # Hide subtest frame if not expanded
                if not data["expanded"].get():
                    subtest_frame.grid_remove()
                
                # Increment row by 2 (one for dropdown button, one for subtest frame)
                row += 2
        else:
            # For non-nested structures (I2C and SPI), use the original method
            for idx, (text, var) in enumerate(checkbox_vars.items()):
                checkbox = ctk.CTkCheckBox(frame, text=text, variable=var, onvalue=True, offvalue=False, font=("Helvetica", 12), command=command)
                checkbox.grid(row=idx, column=0, padx=10, pady=5, sticky="w")
    def toggle_category_expansion(self, category):
        """Toggle whether a category is expanded or collapsed"""
        # Get the current state and toggle it
        expanded = self.checkbox_vars_UART[category]["expanded"]
        expanded.set(not expanded.get())

        # Show or hide this category's subtest frame based on the new state
        if expanded.get():
            self.subtest_frames[category].grid()
        else:
            self.subtest_frames[category].grid_remove()

        # Update all dropdown buttons' arrows only if the frame exists
        if hasattr(self, 'checkbox_frame_UART') and self.checkbox_frame_UART.winfo_exists():
            for widget in self.checkbox_frame_UART.winfo_children():
                if isinstance(widget, ctk.CTkFrame):
                    for child in widget.winfo_children():
                        if isinstance(child, ctk.CTkButton) and category in child.cget("text"):
                            icon = "▼" if expanded.get() else "▶"
                            # Extract the category name without the arrow
                            text_parts = child.cget("text").split(" ", 1)
                            category_text = text_parts[1] if len(text_parts) > 1 else category
                            child.configure(text=f"{icon} {category_text}")
                            break

# Add this method for nested subtest toggling
    def toggle_subtest_expansion(self, category, subtest_name):
        """Toggle whether a nested subtest category is expanded or collapsed"""
        # Get the current state and toggle it
        expanded = self.checkbox_vars_UART[category]["subtests"][subtest_name]["expanded"]
        expanded.set(not expanded.get())
        
        # Make sure the nested_subtest_frames dictionary has the right structure
        if category not in self.nested_subtest_frames:
            self.nested_subtest_frames[category] = {}
        
        if subtest_name in self.nested_subtest_frames[category]:
            # Show or hide the nested subtest frame based on the new state
            if expanded.get():
                self.nested_subtest_frames[category][subtest_name].grid()
            else:
                self.nested_subtest_frames[category][subtest_name].grid_remove()
            
            # Update the nested dropdown button arrow
            for widget in self.subtest_frames[category].winfo_children():
                if isinstance(widget, ctk.CTkFrame):
                    for child in widget.winfo_children():
                        if isinstance(child, ctk.CTkButton) and subtest_name in child.cget("text"):
                            icon = "▼" if expanded.get() else "▶"
                            # Extract just the subtest name without the arrow
                            text_parts = child.cget("text").split(" ", 1)
                            if len(text_parts) > 1:
                                subtest_text = text_parts[1]
                            else:
                                subtest_text = subtest_name
                            child.configure(text=f"{icon} {subtest_text}")
                            break
    def update_main_checkbox(self, category):
        """Update main checkbox based on subtests selection"""
        all_selected = all(var.get() for var in self.checkbox_vars_UART[category]["subtests"].values())
        any_selected = any(var.get() for var in self.checkbox_vars_UART[category]["subtests"].values())
        
        if all_selected:
            self.checkbox_vars_UART[category]["main"].set(True)
        else:
            self.checkbox_vars_UART[category]["main"].set(False)
        
        # Show run test button if any checkbox is selected
        self.show_selection()    
        # Add these methods to your App class

    def reset_ui(self):
        """Clean up UI before setting up a new interface"""
        # Remove existing headers
        for widget in self.winfo_children():
            if isinstance(widget, ctk.CTkLabel) and any(text in str(widget.cget("text")) for text in ["UART Testing", "UART Configuration", "Testing Status"]):
                widget.destroy()
        
        # Remove existing frames that might contain old content
        if hasattr(self, 'result_frame'):
            self.result_frame.destroy()
        if hasattr(self, 'uart_frame'):
            self.uart_frame.destroy()
        if hasattr(self, 'input_frame'):
            self.input_frame.destroy()
        if hasattr(self, 'output_frame'):
            self.output_frame.destroy()
        if hasattr(self, 'rdbnn_frame'):
            self.rdbnn_frame.destroy()

    def create_main_layout(self):
        """Set up the main layout with proper proportions"""
        # Clear main window configuration
        for widget in self.winfo_children():
            widget.destroy()
        
        # Set up the main grid structure
        self.grid_columnconfigure(0, weight=1)  # Left column (UART Testing)
        self.grid_columnconfigure(1, weight=2)  # Middle column (UART Configuration)
        self.grid_columnconfigure(2, weight=1)  # Right column (Result)
        
        # Configure row weights
        self.grid_rowconfigure(0, weight=0)  # Header row
        for i in range(1, 8):
            self.grid_rowconfigure(i, weight=1)
        
        # Create headers with proper spacing
        self.create_headers()
        
        # Create a master frame for scrolling the entire interface
        self.main_frame = ctk.CTkScrollableFrame(
            self,
            width=int(self.winfo_width() * 0.98),
            height=int(self.winfo_height() * 0.9),
            corner_radius=0
        )
        self.main_frame.grid(row=1, column=0, columnspan=3, sticky="nsew", padx=10, pady=10)
        self.main_frame.grid_columnconfigure(0, weight=1)  # Left column
        self.main_frame.grid_columnconfigure(1, weight=2)  # Middle column
        self.main_frame.grid_columnconfigure(2, weight=1)  # Right column
        
        # Set up frames in the scrollable area
        self.create_left_panel()
        self.create_center_panel()
        self.create_right_panel()

    def create_headers(self):
        """Create consistent headers across the top of the UI"""
        header_frame = ctk.CTkFrame(self, fg_color="transparent", height=40)
        header_frame.grid(row=0, column=0, columnspan=3, sticky="ew", padx=10, pady=(10,0))
        header_frame.grid_columnconfigure(0, weight=1)
        header_frame.grid_columnconfigure(1, weight=2)
        header_frame.grid_columnconfigure(2, weight=1)
        
        # Create consistent header style
        header_style = {
            "font": ("Helvetica", 18, "bold"),
            "text_color": "white",
            "fg_color": "#4C6B8B",
            "height": 40,
            "corner_radius": 10
        }
        
        # Add the three main headers
        uart_testing_header = ctk.CTkLabel(
            header_frame,
            text="UART Testing",
            **header_style
        )
        uart_testing_header.grid(row=0, column=0, padx=10, pady=5, sticky="ew")
        
        uart_config_header = ctk.CTkLabel(
            header_frame,
            text="UART Configuration",
            **header_style
        )
        uart_config_header.grid(row=0, column=1, padx=10, pady=5, sticky="ew")
        
        testing_status_header = ctk.CTkLabel(
            header_frame,
            text="Testing Status",
            **header_style
        )
        testing_status_header.grid(row=0, column=2, padx=10, pady=5, sticky="ew")

    def create_left_panel(self):
        """Create the left panel with test categories"""
        # Create a frame for the test categories
        self.test_frame = ctk.CTkFrame(self.main_frame, corner_radius=10)
        self.test_frame.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")
        
        # Create a scrollable frame for test categories
        self.test_scroll = ctk.CTkScrollableFrame(
            self.test_frame,
            width=300,
            height=600,
            corner_radius=5
        )
        self.test_scroll.grid(row=0, column=0, padx=5, pady=5, sticky="nsew")
        self.test_frame.grid_rowconfigure(0, weight=1)
        self.test_frame.grid_columnconfigure(0, weight=1)
        
        # Populate with test categories
        self.populate_checkboxes(self.test_scroll, self.checkbox_vars_UART, self.show_selection)
        
        # Create Run Test button at the bottom of the test panel
        self.test_button = ctk.CTkButton(
            self.test_frame, 
            text="Run Test", 
            image=self.run_test_image if hasattr(self, 'run_test_image') else None,
            command=self.run_test, 
            font=("Helvetica", 16, "bold"),
            width=200, 
            height=40, 
            corner_radius=10,
            fg_color="#1f968e", 
            hover_color="#75ADB9"
        )
        self.test_button.grid(row=1, column=0, pady=10, padx=10, sticky="ew")

    def create_center_panel(self):
        """Create the center panel with UART configuration, DUT Parity, and Input sections"""
        # Create a frame for UART configuration
        self.uart_frame = ctk.CTkFrame(self.main_frame, corner_radius=10)
        self.uart_frame.grid(row=0, column=1, padx=10, pady=10, sticky="nsew")
        self.uart_frame.grid_columnconfigure(0, weight=1)
        self.uart_frame.grid_columnconfigure(1, weight=2)
        
        # UART Configuration Section
        config_label = ctk.CTkLabel(self.uart_frame, text="UART Configuration", font=("Helvetica", 16, "bold"))
        config_label.grid(row=0, column=0, columnspan=2, padx=10, pady=(10,5), sticky="w")
        
        # Baud Rate
        self.baud_rate_label = ctk.CTkLabel(self.uart_frame, text="Baud Rate:")
        self.baud_rate_label.grid(row=1, column=0, padx=10, pady=5, sticky="e")
        self.baud_rate_entry = ctk.CTkOptionMenu(self.uart_frame, values=["600","1200","2400", "4800", "9600","14400","19200","38400","56000","57600", "115200"], state="normal")
        self.baud_rate_entry.grid(row=1, column=1, padx=10, pady=5, sticky="w")
        self.baud_rate_entry.set(9600)
        
        # Stop Bit
        self.stop_bit_label = ctk.CTkLabel(self.uart_frame, text="Stop Bit:")
        self.stop_bit_label.grid(row=2, column=0, padx=10, pady=5, sticky="e")
        self.stop_bit_entry = ctk.CTkEntry(self.uart_frame)
        self.stop_bit_entry.grid(row=2, column=1, padx=10, pady=5, sticky="w")
        
        # Parity
        self.parity_label = ctk.CTkLabel(self.uart_frame, text="Parity:")
        self.parity_label.grid(row=3, column=0, padx=10, pady=5, sticky="e")
        self.parity_var = ctk.StringVar(value="None")
        
        parity_frame = ctk.CTkFrame(self.uart_frame, fg_color="transparent")
        parity_frame.grid(row=3, column=1, padx=10, pady=5, sticky="w")
        
        self.parity_odd = ctk.CTkRadioButton(parity_frame, text="Odd", variable=self.parity_var, value="Odd")
        self.parity_odd.grid(row=0, column=0, padx=10, pady=5, sticky="w")
        self.parity_even = ctk.CTkRadioButton(parity_frame, text="Even", variable=self.parity_var, value="Even")
        self.parity_even.grid(row=0, column=1, padx=10, pady=5, sticky="w")
        self.parity_none = ctk.CTkRadioButton(parity_frame, text="None", variable=self.parity_var, value="None")
        self.parity_none.grid(row=0, column=2, padx=10, pady=5, sticky="w")
        
        # Data Shift
        self.data_shift_label = ctk.CTkLabel(self.uart_frame, text="Data Shift:")
        self.data_shift_label.grid(row=4, column=0, padx=10, pady=5, sticky="e")
        self.data_shift_var = ctk.StringVar(value="MSB First")
        
        shift_frame = ctk.CTkFrame(self.uart_frame, fg_color="transparent")
        shift_frame.grid(row=4, column=1, padx=10, pady=5, sticky="w")
        
        self.data_shift_msb = ctk.CTkRadioButton(shift_frame, text="MSB First", variable=self.data_shift_var, value="MSB First")
        self.data_shift_msb.grid(row=0, column=0, padx=10, pady=5, sticky="w")
        self.data_shift_lsb = ctk.CTkRadioButton(shift_frame, text="LSB First", variable=self.data_shift_var, value="LSB First")
        self.data_shift_lsb.grid(row=0, column=1, padx=10, pady=5, sticky="w")
        
        # Handshake
        self.handshake_label = ctk.CTkLabel(self.uart_frame, text="Handshake:")
        self.handshake_label.grid(row=5, column=0, padx=10, pady=5, sticky="e")
        self.handshake_var = ctk.StringVar(value="OFF")
        
        handshake_frame = ctk.CTkFrame(self.uart_frame, fg_color="transparent")
        handshake_frame.grid(row=5, column=1, padx=10, pady=5, sticky="w")
        
        self.handshake_off = ctk.CTkRadioButton(handshake_frame, text="OFF", variable=self.handshake_var, value="OFF")
        self.handshake_off.grid(row=0, column=0, padx=10, pady=5, sticky="w")
        self.handshake_rts_cts = ctk.CTkRadioButton(handshake_frame, text="RTS/CTS", variable=self.handshake_var, value="RTS/CTS")
        self.handshake_rts_cts.grid(row=0, column=1, padx=10, pady=5, sticky="w")
        self.handshake_xon_xoff = ctk.CTkRadioButton(handshake_frame, text="Xon/Xoff", variable=self.handshake_var, value="Xon/Xoff")
        self.handshake_xon_xoff.grid(row=0, column=2, padx=10, pady=5, sticky="w")
        
        # DUT Parity Set Section
        dut_label = ctk.CTkLabel(self.uart_frame, text="DUT Parity Set", font=("Helvetica", 16, "bold"))
        dut_label.grid(row=7, column=0, columnspan=2, padx=10, pady=(10,5), sticky="w")
        
        self.dut_parity_var = ctk.StringVar(value="None")
        
        dut_parity_frame = ctk.CTkFrame(self.uart_frame, fg_color="transparent")
        dut_parity_frame.grid(row=8, column=0, columnspan=2, padx=10, pady=5, sticky="w")
        
        self.dut_none = ctk.CTkRadioButton(dut_parity_frame, text="None", variable=self.dut_parity_var, value="None", command=self.on_parity_change)
        self.dut_none.grid(row=0, column=0, padx=20, pady=5, sticky="w")
        self.dut_even = ctk.CTkRadioButton(dut_parity_frame, text="Even", variable=self.dut_parity_var, value="Even", command=self.on_parity_change)
        self.dut_even.grid(row=0, column=1, padx=20, pady=5, sticky="w")
        self.dut_odd = ctk.CTkRadioButton(dut_parity_frame, text="Odd", variable=self.dut_parity_var, value="Odd", command=self.on_parity_change)
        self.dut_odd.grid(row=0, column=2, padx=20, pady=5, sticky="w")
        
        # Input Section with more spacing
        input_section_frame = ctk.CTkFrame(self.uart_frame, fg_color="transparent")
        input_section_frame.grid(row=9, column=0, columnspan=2, padx=10, pady=(20,5), sticky="ew")
        
        input_label = ctk.CTkLabel(input_section_frame, text="Input", font=("Helvetica", 16, "bold"))
        input_label.grid(row=0, column=0, padx=10, pady=(0,10), sticky="w", columnspan=2)
        
        input_entry_frame = ctk.CTkFrame(input_section_frame, fg_color="transparent")
        input_entry_frame.grid(row=1, column=0, columnspan=2, padx=10, pady=5, sticky="ew")
        input_entry_frame.grid_columnconfigure(1, weight=1)
        
        input_text_label = ctk.CTkLabel(input_entry_frame, text="Enter Input:")
        input_text_label.grid(row=0, column=0, padx=(0,10), pady=5, sticky="w")
        
        self.input_entry = ctk.CTkEntry(input_entry_frame, placeholder_text="Enter something", height=35)
        self.input_entry.grid(row=0, column=1, padx=10, pady=5, sticky="ew")
        
        # Send button
        self.send_button = ctk.CTkButton(self.uart_frame, text="Send", command=self.submit_input)
        self.send_button.grid(row=10, column=0, columnspan=2, pady=10, padx=20, sticky="ew")
        
        # Submit Configuration Button
        self.submit_button = ctk.CTkButton(
            self.uart_frame, 
            text="Submit Configuration", 
            command=self.submit_uart_configuration
        )
        self.submit_button.grid(row=6, column=0, columnspan=2, pady=10, padx=20, sticky="ew")

    def create_right_panel(self):
        """Create the right panel with test results and testing status"""
        # Create a frame for test results and testing status
        self.result_frame = ctk.CTkFrame(self.main_frame, corner_radius=10)
        self.result_frame.grid(row=0, column=2, padx=10, pady=10, sticky="nsew")
        self.result_frame.grid_columnconfigure(0, weight=1)
        
        # Testing Status Section
        status_label = ctk.CTkLabel(self.result_frame, text="Testing Status", font=("Helvetica", 16, "bold"))
        status_label.grid(row=0, column=0, padx=10, pady=(10,5), sticky="w")
        
        # Create a scrollable frame for testing status
        self.status_scroll = ctk.CTkScrollableFrame(
            self.result_frame,
            width=300,
            height=200,
            corner_radius=5
        )
        self.status_scroll.grid(row=1, column=0, padx=10, pady=5, sticky="nsew")
        
        # Placeholder status label
        self.status_label = ctk.CTkLabel(
            self.status_scroll, 
            text="No tests run yet", 
            font=("Helvetica", 14),
            wraplength=280,
            justify="left"
        )
        self.status_label.grid(row=0, column=0, padx=10, pady=10, sticky="w")
        
        # Output Result Section
        output_label = ctk.CTkLabel(self.result_frame, text="Output Result", font=("Helvetica", 16, "bold"))
        output_label.grid(row=2, column=0, padx=10, pady=(10,5), sticky="w")
        
        # Create a scrollable frame for output results
        self.output_scroll = ctk.CTkScrollableFrame(
            self.result_frame,
            width=300,
            height=200,
            corner_radius=5
        )
        self.output_scroll.grid(row=3, column=0, padx=10, pady=5, sticky="nsew")
        
        # Output result label
        self.output_label = ctk.CTkLabel(
            self.output_scroll, 
            text="Results will appear here", 
            font=("Helvetica", 14),
            wraplength=280,
            justify="left"
        )
        self.output_label.grid(row=0, column=0, padx=10, pady=10, sticky="w")

    def toggle_checkbox_frame_UART(self):
        """Switch to UART testing interface"""
        self.reset_ui()
        self.create_main_layout()
        
        # No need to hide other buttons as we're using a new layout
        
        # Make sure the appropriate UI is visible
        if hasattr(self, 'test_button'):
            self.test_button.grid_forget()  # Hide initially until tests are selected
        
        # Update the UI when size changes
        self.update_idletasks()

    # Modified methods for better UI experience


 
    def toggle_checkbox_frame_I2C(self):
        self.hide_all_checkbox_frames()
        if not self.checkbox_frame_I2C.winfo_ismapped():
            self.checkbox_frame_I2C.grid(row=4, column=0, pady=20, padx=50, sticky="nsew")

    def toggle_checkbox_frame_SPI(self):
        self.hide_all_checkbox_frames()
        if not self.checkbox_frame_SPI.winfo_ismapped():
            self.checkbox_frame_SPI.grid(row=6, column=0, pady=20, padx=50, sticky="nsew")

    def hide_all_checkbox_frames(self):
        self.checkbox_frame_UART.grid_forget()
        self.checkbox_frame_I2C.grid_forget()
        self.checkbox_frame_SPI.grid_forget()

    def show_selection(self):
        """Check if any test is selected and show/hide the test button accordingly"""
        # For UART, use the nested structure
        any_uart_selected = False
        
        # Iterate through the categories in checkbox_vars_UART
        for category_data in self.checkbox_vars_UART.values():
            if "subtests" in category_data:
                # Check if any subtest is selected
                for subtest_var in category_data["subtests"].values():
                    if subtest_var.get():
                        any_uart_selected = True
                        break
            
            # If we already found a selected test, no need to check further
            if any_uart_selected:
                break
        
        # For I2C and SPI, use the original structure
        any_i2c_selected = any(var.get() for var in self.checkbox_vars_I2C.values())
        any_spi_selected = any(var.get() for var in self.checkbox_vars_SPI.values())
        
        # Show test button if any test is selected
        if any_uart_selected or any_i2c_selected or any_spi_selected:
            self.test_button.grid(row=3, column=0, pady=(0,10), padx=50, sticky="ew")
            self.test_button.lift()  # Ensures button appears on top
        else:
            self.test_button.grid_forget()

    def show_headers(self):
        """Create headers and ensure no duplicates"""
        # First, remove any existing headers
        for widget in self.winfo_children():
            if isinstance(widget, ctk.CTkLabel) and any(text in widget.cget("text") for text in ["UART Testing", "UART Configuration", "Testing Status"]):
                widget.destroy()
        
        # Create new headers
        uart_testing_header = ctk.CTkLabel(
            self,
            text="UART Testing",
            font=("Helvetica", 18, "bold"),
            text_color="white",
            fg_color="#4C6B8B",
            height=40,
            corner_radius=10
        )
        uart_testing_header.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="ew")
        
        uart_config_header = ctk.CTkLabel(
            self,
            text="UART Configuration",
            font=("Helvetica", 18, "bold"),
            text_color="white",
            fg_color="#4C6B8B",
            height=40,
            corner_radius=10
        )
        uart_config_header.grid(row=0, column=1, padx=20, pady=(20, 10), sticky="ew")
        
        testing_status_header = ctk.CTkLabel(
            self,
            text="Testing Status",
            font=("Helvetica", 18, "bold"),
            text_color="white",
            fg_color="#4C6B8B",
            height=40,
            corner_radius=10
        )
        testing_status_header.grid(row=0, column=2, padx=20, pady=(20, 10), sticky="ew")

    def show_uart_configuration_form(self):
        # UART configuration form when UART Testing is selected
        # In the show_uart_configuration_form method, add these lines at the start:
    
        self.uart_frame = ctk.CTkFrame(self)
        self.uart_frame.grid(row=2, column=1, pady=20, padx=50, sticky="nsew")
        self.uart_frame.grid_columnconfigure(0, weight=1)
        self.uart_frame.grid_columnconfigure(1, weight=2)

        #self.result_label_title = ctk.CTkLabel( self,  
        #text="UART Configuration",  
        #font=("Helvetica", 16, "bold"),  
        #text_color="#FFFFFF",  
        ##fg_color="#4C6B8B",  
        #corner_radius=10,  
    #)  

        #self.result_label_title.grid(row=1, column=1, sticky="nsew", padx=20, pady=10)

        #title_label = ctk.CTkLabel(self.uart_frame,text="UART Configuration",font=("Helvetica", 18, "bold"),text_color="#000000")
        #title_label.grid(row=1, column=1, columnspan=2, pady=10)

        # for Baud Rate
        self.baud_rate_label = ctk.CTkLabel(self.uart_frame, text="Baud Rate:")
        self.baud_rate_label.grid(row=2, column=0, padx=10, pady=10, sticky="e")
        self.baud_rate_entry = ctk.CTkOptionMenu(self.uart_frame, values=["600","1200","2400", "4800", "9600","14400","19200","38400","56000","57600", "115200"], state="normal")
        self.baud_rate_entry.grid(row=2, column=1, padx=10, pady=10)
        self.baud_rate_entry.set(9600)

        # for Stop Bit
        self.stop_bit_label = ctk.CTkLabel(self.uart_frame, text="Stop Bit:")
        self.stop_bit_label.grid(row=3, column=0, padx=10, pady=10, sticky="e")
        self.stop_bit_entry = ctk.CTkEntry(self.uart_frame)
        self.stop_bit_entry.grid(row=3, column=1, padx=10, pady=10)

        # for Parity
        self.parity_label = ctk.CTkLabel(self.uart_frame, text="Parity:")
        self.parity_label.grid(row=4, column=0, padx=10, pady=10, sticky="e")
        self.parity_var = ctk.StringVar(value="None")
        self.parity_odd = ctk.CTkRadioButton(self.uart_frame, text="Odd", variable=self.parity_var, value="Odd")
        self.parity_odd.grid(row=4, column=1, padx=10, pady=10, sticky="w")
        self.parity_even = ctk.CTkRadioButton(self.uart_frame, text="Even", variable=self.parity_var, value="Even")
        self.parity_even.grid(row=4, column=2, padx=10, pady=10, sticky="w")
        self.parity_none = ctk.CTkRadioButton(self.uart_frame, text="None", variable=self.parity_var, value="None")
        self.parity_none.grid(row=4, column=3, padx=10, pady=10, sticky="w")

        # for Data Shift
        self.data_shift_label = ctk.CTkLabel(self.uart_frame, text="Data Shift:")
        self.data_shift_label.grid(row=5, column=0, padx=10, pady=10, sticky="e")
        self.data_shift_var = ctk.StringVar(value="MSB First")
        self.data_shift_msb = ctk.CTkRadioButton(self.uart_frame, text="MSB First", variable=self.data_shift_var, value="MSB First")
        self.data_shift_msb.grid(row=5, column=1, padx=10, pady=10, sticky="w")
        self.data_shift_lsb = ctk.CTkRadioButton(self.uart_frame, text="LSB First", variable=self.data_shift_var, value="LSB First")
        self.data_shift_lsb.grid(row=5, column=2, padx=10, pady=10, sticky="w")

        # for Handshake
        self.handshake_label = ctk.CTkLabel(self.uart_frame, text="Handshake:")
        self.handshake_label.grid(row=6, column=0, padx=10, pady=10, sticky="e")
        self.handshake_var = ctk.StringVar(value="OFF")
        self.handshake_off = ctk.CTkRadioButton(self.uart_frame, text="OFF", variable=self.handshake_var, value="OFF")
        self.handshake_off.grid(row=6, column=1, padx=10, pady=10, sticky="w")
        self.handshake_rts_cts = ctk.CTkRadioButton(self.uart_frame, text="RTS/CTS", variable=self.handshake_var, value="RTS/CTS")
        self.handshake_rts_cts.grid(row=6, column=2, padx=10, pady=10, sticky="w")
        self.handshake_xon_xoff = ctk.CTkRadioButton(self.uart_frame, text="Xon/Xoff", variable=self.handshake_var, value="Xon/Xoff")
        self.handshake_xon_xoff.grid(row=6, column=3, padx=10, pady=10, sticky="w")

        # Submit Button to process UART config
        image_submitconfig_path = "static/images/submitconfig.png"
        image_submitconfig = Image.open(image_submitconfig_path)
        ctk_image_submitconfig = ctk.CTkImage(light_image=image_submitconfig, dark_image=image_submitconfig)

        self.submit_button = ctk.CTkButton(self.uart_frame, text="Submit Configuration", image = ctk_image_submitconfig, command=self.submit_uart_configuration)
        self.submit_button.grid(row=7, column=0, columnspan=4, pady=20)

        
    def submit_uart_configuration(self):
        """Submit UART configuration with improved error handling"""
        # Get values from the input fields
        baud_rate = self.baud_rate_entry.get()
        stop_bit = self.stop_bit_entry.get()
        parity = self.parity_var.get()
        data_shift = self.data_shift_var.get()
        handshake = self.handshake_var.get()
        
        # Validate inputs
        try:
            # Show processing indicator
            self.status_label.configure(text="Submitting Configuration", text_color="blue")
            self.output_label.configure(text="Processing UART configuration...", text_color="blue")
            self.update_idletasks()
            
            # Validate stop bit
            if not stop_bit:
                raise ValueError("Stop bit must be provided")
            
            stop_bit = float(stop_bit)
            if stop_bit not in [1, 1.5, 2]:
                raise ValueError("Stop bit must be either 1, 1.5, or 2")
            
            # Validate baud rate
            baud_rate = int(baud_rate)
            
            # Process configuration
            result = self.backend.process_uart_configuration(baud_rate, stop_bit, parity, data_shift, handshake)
            
            # Show result
            if "Error" in result:
                self.status_label.configure(text="Configuration Failed", text_color="red")
                self.output_label.configure(text=result, text_color="red")
            else:
                self.status_label.configure(text="Configuration Successful", text_color="green")
                self.output_label.configure(text=result, text_color="green")
        
        except ValueError as e:
            self.status_label.configure(text="Validation Error", text_color="red")
            self.output_label.configure(text=f"Error: {str(e)}", text_color="red")
        except Exception as e:
            self.status_label.configure(text="Unexpected Error", text_color="red")
            self.output_label.configure(text=f"Unexpected error: {str(e)}", text_color="red")
        
        self.update_idletasks()


    def test_backend(self):
        selected_tests = []
        selected_tests += [test for test, var in self.checkbox_vars_UART.items() if var.get()]
        selected_tests += [test for test, var in self.checkbox_vars_I2C.items() if var.get()]
        selected_tests += [test for test, var in self.checkbox_vars_SPI.items() if var.get()]

        if selected_tests:
            threading.Thread(target=self.run_test, daemon=True).start()
        else:
            self.result_label.configure(text="No tests selected", text_color="red")

    def run_test(self):
        selected_tests = []
        
        # Get selected UART tests using the nested structure
        for category, data in self.checkbox_vars_UART.items():
            if "subtests" in data:
                for subtest_name, subtest_var in data["subtests"].items():
                    if isinstance(subtest_var, dict) and "subtests" in subtest_var:
                        # Handle nested subtests
                        for nested_subtest_name, nested_subtest_var in subtest_var["subtests"].items():
                            if nested_subtest_var.get():
                                selected_tests.append(f"{category} - {subtest_name} - {nested_subtest_name}")
                    else:
                        # Handle regular subtests
                        if subtest_var.get():
                            selected_tests.append(f"{category} - {subtest_name}")
        
        # Get selected I2C and SPI tests as before
        selected_tests += [test for test, var in self.checkbox_vars_I2C.items() if var.get()]
        selected_tests += [test for test, var in self.checkbox_vars_SPI.items() if var.get()]
        
        if not selected_tests:
            self.result_label.configure(text="No tests selected", text_color="red")
            return

        # Disable the Run Test button to prevent multiple clicks
        self.test_button.configure(state="disabled")
        
        # Start a new thread for the test execution
        threading.Thread(target=self._run_test_thread, args=(selected_tests,), daemon=True).start()
    def _run_test_thread(self, selected_tests):
        try:
            result = self.backend.run_test(selected_tests)
            # Update status and output labels
            self.after(0, lambda: [
                self.status_label.configure(text=f"Tests run: {', '.join(selected_tests)}", text_color="green"),
                self.output_label.configure(text=result, text_color="green")
            ])
        except Exception as e:
            self.after(0, lambda: [
                self.status_label.configure(text="Test Failed", text_color="red"),
                self.output_label.configure(text=f"Error: {str(e)}", text_color="red")
            ])
        finally:
            self.after(0, lambda: self.test_button.configure(state="normal"))

    def on_resize(self, event):
        """Handle window resize events"""
        width = event.width
        height = event.height

        try:
            # Only configure widgets that exist and are visible
            if hasattr(self, 'test_button') and self.test_button.winfo_exists():
                self.test_button.configure(width=min(int(width * 0.15), 200))

            # Add similar checks for other widgets you're resizing
        except Exception as e:
            # Log the error but don't crash
            print(f"Error during resize: {e}")