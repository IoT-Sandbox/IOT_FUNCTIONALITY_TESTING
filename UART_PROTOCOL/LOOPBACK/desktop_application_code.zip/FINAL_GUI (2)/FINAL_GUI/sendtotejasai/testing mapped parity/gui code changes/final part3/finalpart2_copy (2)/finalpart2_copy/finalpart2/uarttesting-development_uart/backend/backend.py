from gui.gui import App
from .db import Database
import socket
import configparser
import subprocess
import select
import logging

class Backend:
    def __init__(self, host, port, db_config):
        # Set up logging
        self.logger = logging.getLogger(__name__)
        
        # Initialize database
        self.db = Database(db_config)
        self.db.create_tables()
        
        # Network configuration
        self.server_ip = host
        self.server_port = port
        
        # File paths
        self.vi_file_path = r"C:\Users\tejasai\Downloads\DEMO_TEST.vi"
        self.labview_path = self.labview_path = r"C:\ProgramData\Microsoft\Windows\Start Menu\Programs\NI LabVIEW 2025 Q1 (32-bit).lnk"


        # State tracking
        self.config_data = {}
        self.input_data = ""
        self.test_name_ids = {}  # Will store test name IDs
        self.uart_config_id = None  # Will store the current UART config ID
        self.initialize_test_types()
    def initialize_test_types(self):
        """Initialize test types and test names in the database"""
        try:
            # Create UART test type
            uart_type_id = self.db.insert_test_type("UART Testing")


            # Create test names for each test in your UI
            test_names = [
                "Basic UART Communication Test - Reception Test",
                "Basic UART Communication Test - Transmission Test",
                "Basic UART Communication Test - Loopback Test",
                "Configuration Testing - Baud Rate Accuracy Testing",
                "Configuration Testing - Data Bits",
                "Configuration Testing - Stop Bits Configuration",
                "Flow Control Testing - RTS/CTS Hardware Flow Control Test",
                "Flow Control Testing - XON/XOFF Software Flow Test",
                "Error Detection - Parity Detection",
                "Error Detection - Overrun Detection",
                "Error Detection - Framing Detection - BaudRate Mismatch",
                "Error Detection - Framing Detection - StopBit Mismatch",
                "Error Detection - Framing Detection - Break Character Detection",
                "Error Detection - Framing Detection - Noise Detection"
            ]

            # Store test name IDs for later use
            self.test_name_ids = {}

            for test_name in test_names:
                test_name_id = self.db.insert_test_name(uart_type_id, test_name)



                if test_name_id:
                    self.test_name_ids[test_name] = test_name_id

            self.logger.info(f"Initialized {len(self.test_name_ids)} test names")

        except Exception as e:
            self.logger.error(f"Error initializing test types: {e}")

    def process_uart_configuration(self, baud_rate, stop_bit, parity, data_shift, handshake):
        """Process and store UART configuration"""
        try:
            self.config_data = {
                "baudRate": str(baud_rate),
                "parity": str(self.map_parity(parity)),
                "stopBits": str(self.map_stop_bits(stop_bit)),
                "dataBits": "8",
                "dataShift": data_shift,
                "handshake": handshake
            }

            # Store in database if available
            if self.db:
                self.uart_config_id = self.db.insert_uart_config(baud_rate, stop_bit, parity, data_shift, handshake)
                if not self.uart_config_id:
                    return "Error: Failed to save UART configuration"

            # Launch LabVIEW VI
            vi_process = self.run_vi_file()
            if not vi_process:
                return "Error: Failed to launch LabVIEW VI"

            return "Configuration processed and LabVIEW VI launched"
        except Exception as e:
            self.logger.error(f"Configuration error: {e}")
            return f"Configuration error: {e}"

    def run_vi_file(self):
        """Launch LabVIEW VI file"""
        command = f'"{self.labview_path}" "{self.vi_file_path}"'
        try:
            self.logger.info(f"Opening VI file: {self.vi_file_path}")
            process = subprocess.Popen(command, shell=True)
            self.logger.info("VI file opened successfully")
            return process
        except Exception as e:
            self.logger.error(f"Error running VI file: {e}")
            return None

    def send_data_to_labview(self, config_data, input_data, tests):
        """Send configuration and input data to LabVIEW via TCP/IP"""
        client_socket = None
        try:
            client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            client_socket.settimeout(60)
            
            self.logger.info(f"Connecting to LabVIEW at {self.server_ip}:{self.server_port}")
            client_socket.connect((self.server_ip, self.server_port))
            
            # Format message as INI-style string
            message = f"[SerialPort]\n"
            message += f"baudrate = {config_data['baudRate']}\n"
            message += f"parity = {config_data['parity']}\n"
            message += f"stopbits = {config_data['stopBits']}\n"
            message += f"databits = {config_data['dataBits']}\n"
            message += f"datashift = {config_data['dataShift']}\n"
            message += f"handshake = {config_data['handshake']}\n"
            message += f"inputdata = {input_data}\n"
            message += f"operation = {tests}"
            
            self.logger.info(f"Sending data: {message}")
            client_socket.sendall(message.encode('utf-8'))
            
            response = client_socket.recv(1024).decode('utf-8')
            cleaned_response = response.replace('\x00', '').strip()
            self.logger.info(f"Received response: {cleaned_response}")
         
        
            return cleaned_response

        except Exception as e:
            self.logger.error(f"Error sending data: {e}")
            return f"Error: {e}"
        finally:
            if client_socket:
                client_socket.close()

    def receive_data_from_labview(self):
        """Receive data from LabVIEW on a different port"""
        s = None
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.bind((self.server_ip, self.server_port + 1))
            s.listen()
            s.setblocking(False)
        
            self.logger.info("Waiting for LabVIEW response...")
            ready = select.select([s], [], [], 30)  # 30 second timeout
        
            if ready[0]:
                conn, addr = s.accept()
                with conn:
                    self.logger.info(f"Connected by {addr}")
                    data = conn.recv(1024)
                    output_text = data.decode('utf-8')
                    cleaned_output = output_text.replace('\x00', '').strip()
                    self.logger.info(f"Received output: {cleaned_output}")
                
                return cleaned_output
            else:
                self.logger.warning("Timeout waiting for LabVIEW data")
                return None
            
        except Exception as e:
            self.logger.error(f"Error receiving data: {e}")
            return None
        finally:
            if s:
                s.close()
    def map_parity(self, parity):
        return {"None": "0", "Even": "10", "Odd": "20"}.get(parity, "0")
    
    def map_stop_bits(self, stop_bits):
        return {"1": "10", "2": "20"}.get(str(stop_bits), "10")
    
    def process_input_data(self, input_data):
        self.input_data = input_data
        self.logger.info(f"Input data stored in memory: {input_data}")
        return "Input data processed"  # Just store in memory, don't save to DB yet
    def set_parity(self, parity):
        """Set the DUT parity value"""
        self.logger.info(f"DUT parity set to: {parity}")
        # You can add additional logic here if needed

    def get_test_name_id(self, test_name):
        """Find the test name ID for a given test name or partial match"""
        # Exact match
        if test_name in self.test_name_ids:
            return self.test_name_ids[test_name]

        # Partial match
        for name, id_value in self.test_name_ids.items():
            if test_name in name:
                return id_value

        # No match found
        return None

    def run_test(self, selected_tests):
        """Execute test with current configuration and input data"""
        try:
            self.logger.info(f"Selected tests: {selected_tests}")
            self.logger.info(f"Available test names: {list(self.test_name_ids.keys())}")
            self.logger.info(f"Test name IDs dictionary: {self.test_name_ids}")
            if not self.config_data:
                return "Error: Configuration data missing"
            if not self.input_data:
                return "Error: Input data missing"
            if not self.uart_config_id:
                return "Error: UART configuration not saved"

            operation = ",".join(selected_tests)
            # Find the appropriate test_name_id based on the selected test
            test_name_id = None
            

            # Try to find an exact match for the first selected test
            if selected_tests:
                test_name = selected_tests[0]
                # Check if it's a category with a specific test
                if " - " in test_name:
                    test_name_id = self.get_test_name_id(test_name)
                else:
                    # It's a category name, try to find a test that starts with this category
                    for name, id_value in self.test_name_ids.items():
                        if name.startswith(test_name):
                            test_name_id = id_value
                            break

            # If no test_name_id found, use the first one as fallback
            if not test_name_id and self.test_name_ids:
                test_name_id = next(iter(self.test_name_ids.values()))
                self.logger.warning(f"No matching test found, using default test ID: {test_name_id}")

            if not test_name_id:
                return "Error: No valid test name found"
            # Create initial record with input data
            record_id = self.db.create_test_record(
                uart_configuration_id=self.uart_config_id,
                test_name_id=test_name_id,
                input_data=self.input_data,
                operation=operation
            )
            
            if record_id is None:
                return "Error: Failed to create test record"

            # Send data to LabVIEW
            response = self.send_data_to_labview(
                self.config_data,
                self.input_data,
                operation
            )

           # Update record with output data
            result_status = "Pass" if "Error" not in response else "Fail"
            self.db.update_test_output(record_id, response, result_status)

            return f"Test execution completed. Response: {response}"

        except Exception as e:
            self.logger.error(f"Test execution failed: {str(e)}")
            return f"Test execution failed: {str(e)}"