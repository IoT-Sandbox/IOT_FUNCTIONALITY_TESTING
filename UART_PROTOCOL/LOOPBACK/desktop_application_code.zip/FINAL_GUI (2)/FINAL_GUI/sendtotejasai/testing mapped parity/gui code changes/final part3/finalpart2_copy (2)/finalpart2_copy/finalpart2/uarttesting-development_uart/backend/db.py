import psycopg2
from psycopg2 import sql
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class Database:
    def __init__(self, db_config):
        self.db_config = db_config

    def connect(self):
        try:
            conn = psycopg2.connect(**self.db_config)
            return conn
        except psycopg2.Error as e:
            logger.error(f"Error connecting to the database: {e}")
            return None

    def create_tables(self):
        """Create only the required tables for the desktop application."""
        conn = self.connect()
        if conn is None:
            return

        try:
            with conn.cursor() as cur:
                # Create test_types table
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS test_types (
                        id SERIAL PRIMARY KEY,
                        test_category VARCHAR(50) NOT NULL
                    )
                """)
                
                # Create test_names table
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS test_names (
                        id SERIAL PRIMARY KEY,
                        test_type_id INT REFERENCES test_types(id) ON DELETE CASCADE,
                        test_name VARCHAR(50)
                    )
                """)

                # Create UART configuration table
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS uart_configuration (
                        id SERIAL PRIMARY KEY,
                        baud_rate INTEGER,
                        stop_bits NUMERIC(2,1),
                        parity VARCHAR(10),
                        data_shift VARCHAR(20),
                        handshake VARCHAR(20),
                        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)

                # Create test_results table
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS test_results (
                        id SERIAL PRIMARY KEY,
                        uart_configuration_id INT REFERENCES uart_configuration(id) ON DELETE CASCADE,
                        test_name_id INT REFERENCES test_names(id) ON DELETE CASCADE,
                        input_data TEXT NOT NULL,
                        output_data TEXT,
                        operation VARCHAR(100),
                        result VARCHAR(20),
                        input_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        output_timestamp TIMESTAMP
                    )
                """)

                conn.commit()
                logger.info("Required tables created successfully")
        except psycopg2.Error as e:
            logger.error(f"Error creating tables: {e}")
        finally:
            conn.close()

    def insert_uart_config(self, baud_rate, stop_bit, parity, data_shift, handshake):
        """Insert a new UART configuration."""
        conn = self.connect()
        if conn is None:
            return None

        try:
            with conn.cursor() as cur:
                cur.execute("""
                    INSERT INTO uart_configuration 
                    (baud_rate, stop_bits, parity, data_shift, handshake)
                    VALUES (%s, %s, %s, %s, %s)
                    RETURNING id
                """, (baud_rate, stop_bit, parity, data_shift, handshake))
                config_id = cur.fetchone()[0]
                conn.commit()
                logger.info(f"UART configuration inserted with id: {config_id}")
                return config_id
        except psycopg2.Error as e:
            logger.error(f"Error inserting UART configuration: {e}")
            return None
        finally:
            conn.close()

    def get_latest_uart_config_id(self):
        """Get the ID of the most recent UART configuration."""
        conn = self.connect()
        if conn is None:
            return None

        try:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT id FROM uart_configuration
                    ORDER BY timestamp DESC
                    LIMIT 1
                """)
                result = cur.fetchone()
                if result:
                    return result[0]
                return None
        except psycopg2.Error as e:
            logger.error(f"Error getting latest UART config ID: {e}")
            return None
        finally:
            conn.close()

    def create_test_record(self, uart_configuration_id, test_name_id, input_data, operation):
        """Insert a new test record in test_results."""
        conn = self.connect()
        if conn is None:
            return None

        try:
            with conn.cursor() as cur:
                cur.execute("""
                    INSERT INTO test_results
                    (uart_configuration_id, test_name_id, input_data, operation, input_timestamp)
                    VALUES (%s, %s, %s, %s, CURRENT_TIMESTAMP)
                    RETURNING id
                """, (uart_configuration_id, test_name_id, input_data, operation))
                record_id = cur.fetchone()[0]
                conn.commit()
                logger.info(f"Test record created with id: {record_id}")
                return record_id
        except psycopg2.Error as e:
            logger.error(f"Error creating test record: {e}")
            return None
        finally:
            conn.close()

    def update_test_output(self, record_id, output_data, result="Complete"):
        """Update the output of a test record in test_results."""
        conn = self.connect()
        if conn is None:
            return

        try:
            with conn.cursor() as cur:
                cleaned_output = output_data.replace('\x00', '').strip() if output_data else ''
                cur.execute("""
                    UPDATE test_results
                    SET output_data = %s, result = %s, output_timestamp = CURRENT_TIMESTAMP
                    WHERE id = %s
                """, (cleaned_output, result, record_id))
                conn.commit()
                logger.info(f"Test record {record_id} updated with output")
        except psycopg2.Error as e:
            logger.error(f"Error updating test output: {e}")
        finally:
            conn.close()

    def insert_test_type(self, test_category):
        """Insert a new test type."""
        conn = self.connect()
        if conn is None:
            return None

        try:
            with conn.cursor() as cur:
                # Check if test type already exists
                cur.execute("""
                    SELECT id FROM test_types
                    WHERE test_category = %s
                """, (test_category,))

                existing = cur.fetchone()
                if existing:
                    logger.info(f"Test type '{test_category}' already exists with id: {existing[0]}")
                    return existing[0]

                # Insert new test type
                cur.execute("""
                    INSERT INTO test_types (test_category)
                    VALUES (%s)
                    RETURNING id
                """, (test_category,))

                test_type_id = cur.fetchone()[0]
                conn.commit()
                logger.info(f"Test type '{test_category}' inserted with id: {test_type_id}")
                return test_type_id
        except psycopg2.Error as e:
            logger.error(f"Error inserting test type: {e}")
            return None
        finally:
            conn.close()

    def insert_test_name(self, test_type_id, test_name):
        """Insert a new test name linked to a test type."""
        conn = self.connect()
        if conn is None:
            return None

        try:
            with conn.cursor() as cur:
                # Check if test name already exists
                cur.execute("""
                    SELECT id FROM test_names
                    WHERE test_name = %s
                """, (test_name,))

                existing = cur.fetchone()
                if existing:
                    logger.info(f"Test name '{test_name}' already exists with id: {existing[0]}")
                    return existing[0]

                # Insert new test name
                cur.execute("""
                    INSERT INTO test_names (test_type_id, test_name)
                    VALUES (%s, %s)
                    RETURNING id
                """, (test_type_id, test_name))

                test_name_id = cur.fetchone()[0]
                conn.commit()
                logger.info(f"Test name '{test_name}' inserted with id: {test_name_id}")
                return test_name_id
        except psycopg2.Error as e:
            logger.error(f"Error inserting test name: {e}")
            return None
        finally:
            conn.close()

    def get_test_name_id(self, test_name):
        """Get the ID of a test name."""
        conn = self.connect()
        if conn is None:
            return None

        try:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT id FROM test_names
                    WHERE test_name = %s
                """, (test_name,))
                result = cur.fetchone()
                if result:
                    return result[0]
                return None
        except psycopg2.Error as e:
            logger.error(f"Error getting test name ID: {e}")
            return None
        finally:
            conn.close()

# Usage example:
if __name__ == "__main__":
    db_config = {
        'dbname': 'uart_testing',
        'user': 'postgres',
        'password': 'tejasai',
        'host': 'localhost',
        'port': '5432'
    }

    db = Database(db_config)
    db.create_tables()

    # Initialize test types and names
    uart_type_id = db.insert_test_type("UART Testing")

    # Create basic test names
    test_names = [
        "Basic UART Communication Test - Reception Test",
        "Basic UART Communication Test - Transmission Test",
        "Basic UART Communication Test - Loopback Test",
        "Configuration Testing - Baud Rate Accuracy Testing",
        "Configuration Testing - Data Bits",
        "Configuration Testing - Stop Bits Configuration",
        "Flow Control Testing - RTS/CTS Hardware Flow Control Test",
        "Flow Control Testing - XON/XOFF Software Flow Test",
        "Error Detection - Parity Detection",
        "Error Detection - Overrun Detection",
        "Error Detection - Framing Detection - BaudRate Mismatch",
        "Error Detection - Framing Detection - StopBit Mismatch",
        "Error Detection - Framing Detection - Break Character Detection",
        "Error Detection - Framing Detection - Noise Detection"
    ]

    for name in test_names:
        db.insert_test_name(uart_type_id, name)