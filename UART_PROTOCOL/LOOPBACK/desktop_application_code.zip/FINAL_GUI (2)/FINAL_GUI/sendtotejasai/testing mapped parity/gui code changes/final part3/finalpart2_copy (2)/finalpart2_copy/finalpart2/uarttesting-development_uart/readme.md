# MyTestBox

MyTestBox is a Python-based desktop application designed as an automation tool that facilitates the testing of Devices Under Test (DUTs). 
The application allows users to send commands through a graphical user interface (GUI), which are then processed by LabVIEW for testing. 
The results of these tests are stored in a PostgreSQL database.

## Features

- **User-Friendly GUI**: Built with CustomTkinter for an intuitive user experience.
- **Command Automation**: Send commands directly from the GUI to LabVIEW.
- **Database Integration**: Store and retrieve test results using PostgreSQL.
- **Cross-Platform Compatibility**: Works on various operating systems where Python is supported.

## Prerequisites

Before you begin, ensure you have the following installed:

- Python 3.x
- PostgreSQL
- Required Python libraries (listed in `requirements.txt`)

## Installation

Follow these steps to set up MyTestBox on your local machine:

1. Clone the repository:
   ```bash
   git clone https://github.com/iotsandbox/uarttesting.git
