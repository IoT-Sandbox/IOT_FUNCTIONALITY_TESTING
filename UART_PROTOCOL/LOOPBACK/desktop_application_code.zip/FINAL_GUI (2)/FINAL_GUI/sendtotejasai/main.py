import logging
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend import backend
from gui.gui import App
import customtkinter as ctk

logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def main():
    try:
        # Initialize backend with database configuration
        backend_instance = backend.Backend(
            host='127.0.0.1',  # LabVIEW socket host
            port=12345,        # LabVIEW socket port
            db_config={
                'dbname': 'uart_test',
                'user': 'postgres',
                'password': 'tejasai',  # Replace with your actual password
                'host': 'localhost',
                'port': '5432'
            }
        )

        # Set up CustomTkinter
        ctk.set_appearance_mode("system")
        ctk.set_default_color_theme("blue")

        # Create the application
        app = App(backend_instance)
        
        logger.info("Application started successfully")
        
        # Run the application
        app.mainloop()

    except Exception as e:
        logger.error(f"Error starting application: {e}", exc_info=True)
        sys.exit(1)

if __name__ == "__main__":
    main()